###############################################################################
# ActiveSpaces Tools
# 
# Version 0.8.1 - Pierre Ayel - 2023/06/19
#
###############################################################################

Changes
  Version 0.8.1 - Pierre Ayel - 2023/06/19
    Changed tracing of "Datagrid version" into "Client version"
  Version 0.8.0 - Pierre Ayel - 2021
    Stable version    
  Version 0.7.2 - Pierre Ayel - 2020/10/23
    TableExport:
      Added support for querying data from a datagrid existing checkpoint: --checkpoint <name>
      
###############################################################################
###  END OF FILE  #############################################################
###############################################################################

